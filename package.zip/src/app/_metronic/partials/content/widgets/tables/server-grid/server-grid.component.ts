import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/api';
import { GridServiceService } from './grid-service.service';

interface Product {
  id?: string;
  user_id?: any;
  title?: any;
  body?: any;
}

@Component({
  selector: 'app-server-grid',
  templateUrl: './server-grid.component.html',
  styleUrls: ['./server-grid.component.scss']
})
export class ServerGridComponent implements OnInit {
  @ViewChild('dt') dt: any
  public data: Object[];
  public initialSort: Object;
  public pageSettings: Object;

  url: any = "https://gorest.co.in/public/v2/todos"

  // id: any = []

  id: any = ""

  error:any = ""
  

  userId: any = []

  productDialog: boolean;

  products: Product[];

  product: Product;

  selectedProducts: Product[];

  submitted: boolean;

  constructor(private messageService: MessageService, private confirmationService: ConfirmationService, private gridservice: GridServiceService, private http: HttpClient, private ref: ChangeDetectorRef) { }

  ngOnInit() {
    this.getadetails()
  }

  filter($event: any) {
    this.dt.filterGlobal($event.target.value, 'contains');
  }

  hideDialog() {
    this.productDialog = false;
    this.submitted = false;
  }

  openNew() {
    this.product = {};
    this.submitted = false;
    this.productDialog = true;
  }

  getadetails() {
    this.gridservice.getAll().subscribe((data: Product[]) => {
      this.userId = data;
      this.ref.detectChanges()
    })
  }

  editUser(id: any) {
    this.productDialog = true
    this.gridservice.find(id).subscribe((data: Product) => {
      this.product = data;
    });
  }

  deleteUser(id: any) {
    this.gridservice.delete(id).subscribe(res => {
      this.userId = this.userId.filter((item: any) => item.id !== id);
      this.ref.detectChanges()
    })
  }

  adduser() {
    debugger

    const value = {
      "user_id": this.product.user_id,
      "title": this.product.title,
      "body": this.product.body
    }

    this.gridservice.create(value).subscribe(
      res => console.log('HTTP response', res),
      err => console.log('HTTP Error', err),
      () => console.log('HTTP request completed.')
      // Window.alert();

  )
                                               
    // this.gridservice.create(value).subscribe((res: any) => {
    //   this.userId = res
    //   console.log("subscribe")
    // },
    //   (error: any) => {
    //     this.error = error
    //     console.log("error")
    //   })
    
  }

  updateUser() {
    debugger
    const value = {
      "id": this.product.id,
      "user_id": this.product.user_id,
      "title": this.product.title,
      "body": this.product.body
    }

    this.gridservice.update(value).subscribe((res: any) => {
      this.userId = res
      this.getadetails()
      console.log("user update")
    })
  }


  saveProduct(id: any) {
    this.submitted = true
    if (id != null) {
      //    this.updateUser()
      //    this.productDialog = false
      //  }
      //  else{
      this.adduser()
      this.productDialog = false
    }
  }

}
