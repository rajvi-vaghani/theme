import { HttpClient, HttpHeaders } from '@angular/common/http';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

interface Post {
    id: number;
    title: string;
    body: string;
}

@Injectable({
    providedIn: 'root'
})
export class GridServiceService {
    token: any = "0325b7453bc4c07c12693a00eb7e0cc005e7b629f4d2eff33ab92fa765d34497"
    private apiURL = "https://gorest.co.in/public/v2/posts";

    httpOptions = {
        headers: new HttpHeaders({
            // "header name " : "header value"
            'Authorization': 'Bearer ' + this.token
        })
    }

    constructor(private httpClient: HttpClient) { }

    getAll(): Observable<any> {
        return this.httpClient.get(this.apiURL , this.httpOptions)
        .pipe(
            catchError(this.errorHandler)
          )
    }

    // create(post:Post , value:any): Observable<any> {
    create(value:any): Observable<any> {
        return this.httpClient.post(this.apiURL , this.httpOptions)
        .pipe(
            catchError(this.errorHandler)
          )
    }

    find(id: any): Observable<any> {

        return this.httpClient.get(this.apiURL + '/' + id)
        .pipe(
            catchError(this.errorHandler)
          )
    }

    // update(id: any, post: Post): Observable<any> {
        update(id: any): Observable<any> {
        return this.httpClient.put(this.apiURL + '/' + id, this.httpOptions)
        .pipe(
            catchError(this.errorHandler)
          )
    }

    delete(id: any) {
        return this.httpClient.delete(this.apiURL + '/' + id, this.httpOptions)
        .pipe(
            catchError(this.errorHandler)
          )
    }

    errorHandler(error:any) {
        let errorMessage = '';
        if(error.error instanceof ErrorEvent) {
          errorMessage = error.error.message;
        } else {
          errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        return throwError(errorMessage);
     }

}
