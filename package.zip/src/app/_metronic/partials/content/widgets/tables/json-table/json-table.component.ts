import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';

interface Country {
  id?: number;
  name: string;
  flag: string;
  area: number;
  population: number;
}
const COUNTRIES: Country[] = [
  {
    name: 'Russia',
    flag: 'f/f3/Flag_of_Russia.svg',
    area: 17075200,
    population: 146989754
  },
  {
    name: 'France',
    flag: 'c/c3/Flag_of_France.svg',
    area: 640679,
    population: 64979548
  }
]


@Component({
  selector: 'app-json-table',
  templateUrl: './json-table.component.html',
  styleUrls: ['./json-table.component.scss']
})
export class JsonTableComponent implements OnInit {
  page = 1;
  pageSize = 4;
  collectionSize = COUNTRIES.length;
  countries: Country[];
  newData:any = []
  userData:any = []
  constructor(private http : HttpClient, private ref : ChangeDetectorRef) { 
  
  }

  ngOnInit(): void {
    this.getData()
    
    // this.refreshCountries();
  }

  // refreshCountries() {
  //   this.countries = COUNTRIES
  //     .map((country, i) => ({id: i + 1, ...country}))
  //     .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  // }


  getData(){
    this.http.get(`${environment.apiEndPoint}`).subscribe((res:any)=>{
      this.userData = res
      // this.collectionSize = this.userData.length
      // this.refreshCountries()
      // this.collectionSize = COUNTRIES.length
      this.ref.detectChanges()
    })
  }

}
