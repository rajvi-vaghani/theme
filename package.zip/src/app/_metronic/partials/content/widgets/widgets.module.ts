import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgApexchartsModule } from 'ng-apexcharts';
import { InlineSVGModule } from 'ng-inline-svg';
import { DropdownMenusModule } from '../dropdown-menus/dropdown-menus.module';
import { NgbDropdownModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TablesWidget11Component } from './tables/tables-widget11/tables-widget11.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ServerGridComponent } from './tables/server-grid/server-grid.component';
import { TableModule } from 'primeng/table';
import { ToastModule } from 'primeng/toast';
import { CalendarModule } from 'primeng/calendar';
import { SliderModule } from 'primeng/slider';
import { MultiSelectModule } from 'primeng/multiselect';
import { ContextMenuModule } from 'primeng/contextmenu';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { DropdownModule } from 'primeng/dropdown';
import { ProgressBarModule } from 'primeng/progressbar';
import { InputTextModule } from 'primeng/inputtext';
import { FileUploadModule } from 'primeng/fileupload';
import { ToolbarModule } from 'primeng/toolbar';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputNumberModule } from 'primeng/inputnumber';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { InputTextareaModule } from 'primeng/inputtextarea';
import {AutoCompleteModule} from 'primeng/autocomplete';
@NgModule({
  declarations: [
    TablesWidget11Component,
    ServerGridComponent
  ],
  imports: [
    CommonModule,
    DropdownMenusModule,
    InlineSVGModule,
    NgApexchartsModule,
    NgbDropdownModule,
    FormsModule,
    ReactiveFormsModule,
    InputTextModule,
    ProgressBarModule,
    ButtonModule,
    NgbModule,
    MultiSelectModule,
    ToastModule,
    ContextMenuModule,
    SliderModule,
    AutoCompleteModule,
    CalendarModule,
    TableModule,
    DialogModule,
    FileUploadModule,
    ToolbarModule,
    DropdownModule,
    InputTextareaModule,
    ConfirmDialogModule,
    InputNumberModule,
    RadioButtonModule

  ],
  exports: [
    TablesWidget11Component
  ],
})
export class WidgetsModule { }
