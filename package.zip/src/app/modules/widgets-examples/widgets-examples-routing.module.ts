import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { JsonTableComponent } from 'src/app/_metronic/partials/content/widgets/tables/json-table/json-table.component';
import { ServerGridComponent } from 'src/app/_metronic/partials/content/widgets/tables/server-grid/server-grid.component';
import { TablesComponent } from './tables/tables.component';
import { WidgetsExamplesComponent } from './widgets-examples.component';

const routes: Routes = [
  {
    path: '',
    component: WidgetsExamplesComponent,
    children: [

      {
        path: 'tables',
        component: TablesComponent,
      },
      {
        path: "jsontable",
        component: JsonTableComponent
      },
      {
        path: "server-grid",
        component: ServerGridComponent
      },
      { path: '', redirectTo: 'lists', pathMatch: 'full' },
      { path: '**', redirectTo: 'lists', pathMatch: 'full' },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class WidgetsExamplesRoutingModule {}
