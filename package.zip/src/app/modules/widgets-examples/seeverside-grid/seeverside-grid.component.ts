import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seeverside-grid',
  templateUrl: './seeverside-grid.component.html',
  styleUrls: ['./seeverside-grid.component.scss']
})
export class SeeversideGridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
