import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SeeversideGridComponent } from './seeverside-grid.component';

describe('SeeversideGridComponent', () => {
  let component: SeeversideGridComponent;
  let fixture: ComponentFixture<SeeversideGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SeeversideGridComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SeeversideGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
