import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FacebookLoginProvider, SocialUser } from 'ng-social-login-module';
import { AuthService, GoogleLoginProvider } from 'ng-social-login-module';

@Component({
  selector: 'app-sign-with-google',
  templateUrl: './sign-with-google.component.html',
  styleUrls: ['./sign-with-google.component.scss']
})
export class SignWithGoogleComponent implements OnInit {

  login!: FormGroup
  private user: SocialUser;
  private loggedIn: boolean;
  constructor(private authService: AuthService, private fb: FormBuilder) {
    this.login = this.fb.group({
      name: []
    })
  }

  signInWithGoogle(): void {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID);
  }

  signInWithFacebook():void {
    this.authService.signIn(FacebookLoginProvider.PROVIDER_ID)
  }

  signOut(): void {
    this.authService.signOut();
  }

  ngOnInit() {
    this.authService.authState.subscribe((user:any) => {
      this.user = user;
      this.loggedIn = (user != null)
    })
  }

}
