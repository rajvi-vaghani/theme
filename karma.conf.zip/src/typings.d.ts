declare var ClipboardJS: any;
